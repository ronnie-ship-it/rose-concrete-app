# Before You Open Claude Code — Do These First
# Complete this list and Claude Code can build without stopping to ask you anything.

---

## STEP 1 — Drop CLAUDE.md into your project (5 min)
1. Download CLAUDE.md from this folder
2. Drop it into: C:\Users\thoma\OneDrive\Desktop\rose-concrete-app\
3. Done — Claude Code reads it automatically every session, no pasting needed

---

## STEP 2 — Set up Supabase (15 min)
1. Go to https://supabase.com — sign in or create a free account
2. Click New Project → name it "rose-concrete" → pick a strong password → region: West US
3. Wait ~2 min for it to spin up
4. Go to Project Settings → API
5. Copy these three values:
   - Project URL (looks like https://xxxx.supabase.co)
   - anon public key (long string starting with eyJ)
   - service_role key (another long string starting with eyJ)
6. In your project folder, copy .env.local.example → rename the copy to .env.local
7. Paste the three values into .env.local
8. Go to Supabase → SQL Editor → New Query
9. Open migrations/001_init.sql, copy everything, paste it in, click Run
10. You should see "Success" — database is live

---

## STEP 3 — Drop in your logo (2 min)
1. Find the Rose Concrete logo as a square PNG (1024x1024 or larger)
2. Drop it into: C:\Users\thoma\OneDrive\Desktop\rose-concrete-app\public\
3. Name it: logo.png
Claude Code will resize it into the PWA icons automatically

---

## STEP 4 — Install dependencies (2 min)
1. Open a terminal (Win+R → type cmd → Enter)
2. cd C:\Users\thoma\OneDrive\Desktop\rose-concrete-app
3. npm install
4. Wait for it to finish

---

## STEP 5 — Open Claude Code and start building
Once Steps 1-4 are done, open Claude Code and type exactly this:

  "CLAUDE.md is in the project. Supabase is live. Start building Phase 1 from item 1."

Claude Code will read CLAUDE.md and start building without you needing to explain anything.

---

## STEP 6 — Reconnect Jobber + OpenPhone (do when you have 5 min)
Both MCP plugins were broken as of early April.
1. Open Claude Code → Settings → Integrations or MCP Servers
2. Find Jobber — disconnect and reconnect
3. Find OpenPhone — disconnect and reconnect
4. If stuck, type in Claude Code: "Help me reconnect Jobber and OpenPhone MCP plugins"

---

## STEP 7 — Request DocuSign beta access (do when you have 2 min)
This unlocks auto-sending contracts when a quote gets approved.
1. Go to: https://developers.docusign.com
2. Look for MCP integration and request beta access
3. Once approved, tell Claude Code: "DocuSign beta is approved, wire the contract auto-send"

---

## STEP 8 — Set up your 5 AI Agents in Claude.ai (optional, do anytime)
See AGENT_SYSTEM_PROMPTS.md for the full prompts.
1. claude.ai → Projects → New Project
2. Name it (e.g. RC Ops)
3. Paste the matching system prompt from AGENT_SYSTEM_PROMPTS.md into Project Instructions
4. Connect the tools listed at the top of each agent
5. Repeat for all 5

Start with RC Ops and RC Sales — those are useful right now even before the app is built.
