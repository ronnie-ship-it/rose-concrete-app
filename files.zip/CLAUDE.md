# Rose Concrete App — Claude Code Instructions
# This file is auto-read by Claude Code at the start of every session.
# Do not delete it. Update it when major things change.

---

## YOUR JOB
Build a full business management system for Rose Concrete and Development LLC.
The owner (Ronnie) wants to pour concrete and have AI handle everything else.
Every feature you build should reduce time Ronnie spends at a computer.

---

## WHO RONNIE IS
- **Name:** Thomas Rose — goes by "Ronnie"
- **Business:** Rose Concrete and Development LLC, San Diego CA
- **License:** CA #1130763
- **Email:** ronnie@sandiegoconcrete.ai
- **Signs all comms as:** Ronnie
- **Brand name:** Rose Concrete and Development
- **Model:** Mobile — no office. Crew of 1099 contractors + rotating day laborers.
- **Tools he uses:** Gmail, Jobber, QuickBooks Online, OpenPhone (he calls it "Quo"), MOASURE (measurement app, low-tier, no export)

---

## PROJECT LOCATION
```
C:\Users\thoma\OneDrive\Desktop\rose-concrete-app
```

---

## TECH STACK
| Layer | Choice | Notes |
|---|---|---|
| Framework | Next.js 15 App Router | |
| Database | Supabase | Postgres + Auth + Storage + RLS |
| Hosting | Vercel | |
| Styling | Tailwind CSS | |
| Validation | Zod | |
| Contracts | DocuSign | Account ID: e9b3a88c-4fc1-4c86-a098-24e31ee82b13 — beta access pending |
| CRM | Jobber | MCP plugin — reconnect if broken |
| Phone | OpenPhone ("Quo") | MCP plugin — reconnect if broken |
| Accounting | QuickBooks Online | MCP connected |
| Email | Gmail | MCP connected |
| Measurements | MOASURE | No API — manual sqft + cubic_yards entry per project |

---

## WHAT IS ALREADY BUILT

### Phase 0 — Complete ✅
- Next.js 15 project scaffolded
- Supabase schema: `migrations/001_init.sql`
  - Tables: profiles, clients, projects, quotes, quote_line_items, visits, photos, job_costs, marketing_metrics, feature_flags
  - Roles: admin | office | crew
  - RLS: crew sees only their assigned jobs + photos
  - Feature flags seeded for all Phase 1–3 modules
- PWA manifest wired (`public/manifest.webmanifest`)
- Supabase server + browser clients (`lib/supabase/`)
- Jobber import stub (`scripts/import-jobber.ts`)
- `.env.local.example` with all required keys

---

## WHAT TO BUILD NEXT — PHASE 1

Work through this list in order. Check items off as you complete them.

- [ ] 1. Auth + roles — Supabase Auth, admin/office/crew roles, invite by email, redirect after login based on role
- [ ] 2. Client list — search, add, edit, full contact info, view project history per client
- [ ] 3. Project screen — linked to client, status pipeline (lead → quoted → active → complete), MOASURE fields (sqft, cubic_yards), notes
- [ ] 4. Quote builder — line items, material + labor split, margin calculator, MOASURE auto-fill from project, PDF preview, send to client button
- [ ] 5. Public quote page — customer-facing, mobile-optimized, shows line items + total + deposit info, Approve button
- [ ] 6. DocuSign auto-send — triggers on quote approval, sends 3-yr warranty + 50% non-refundable deposit contract (wire when beta access approved)
- [ ] 7. Scheduling / visit calendar — drag-drop, placeholder visits (auto-flagged), crew assignment, SMS confirmation stub
- [ ] 8. Crew PWA — installable on iOS + Android, daily job view, photo upload with phone camera, photos tagged to project
- [ ] 9. Daily command center — morning briefing pulling Gmail + Jobber + QBO: open quotes, unpaid invoices, unread messages, today's visits
- [ ] 10. Smart OpenPhone intake — unknown caller → auto-create client + draft quote → outbound text for missing info → placeholder visit on calendar

---

## PHASE 2 (after Phase 1 live ~30 days)
- QuickBooks per-job profitability dashboard (revenue / cost / margin per project)
- Google Ads autonomous agent — shadow mode first, then live with guardrails
- Material purchase list auto-draft from approved quote measurements
- Subcontractor 1099 onboarding flow

## PHASE 3
- Voice crew updates
- Customer portal
- Compliance autopilot (insurance, licensing renewals)
- Capacitor wrapper for true native iOS/Android (if PWA hits limits)

---

## KEY BUSINESS RULES — NEVER CHANGE WITHOUT ASKING RONNIE
- Deposit: 50% non-refundable (default in every quote + contract)
- Warranty: 3 years standard, in every contract
- Crew are 1099 contractors — no W2 payroll
- Day laborers tracked by journal, not profiles
- MOASURE: enter sqft + cubic_yards manually per project — no API available
- Google Ads keyword whitelist: driveways, stamped concrete driveways, pickleball courts, patios, RV pads, sidewalks — San Diego County only
- Public brand: Rose Concrete and Development

---

## MULTI-AGENT ARCHITECTURE (build toward this)
The app supports 5 focused AI agents. Design API routes and data model with this in mind.

| Agent | Scope |
|---|---|
| Ops Agent | Daily briefing, Gmail triage, follow-up drafts |
| Sales Agent | Lead intake, quote building, DocuSign, follow-up texts |
| Field Agent | Crew scheduling, photo tagging, visit updates |
| Finance Agent | QBO sync, per-job profitability, invoice tracking |
| Marketing Agent | Google Ads monitoring, lead source dashboard |

---

## OUTSTANDING BLOCKERS
If you hit one of these, skip that feature and build the next item on the list.

| Blocker | Unblocks |
|---|---|
| Supabase URL + anon key + service_role key in .env.local | Everything |
| Run migrations/001_init.sql in Supabase SQL editor | Everything |
| Rose Concrete logo (square PNG, 1024x1024) | PWA icon, app header, quote pages |
| Reconnect Jobber MCP plugin | Command center, data import |
| Reconnect OpenPhone MCP plugin | Smart intake, call logs |
| Request DocuSign MCP beta access | Auto-send contracts |
| Confirm deposit % (currently 50%) | Contract template |

---

## CODING STANDARDS
- TypeScript everywhere — no any types
- Server Components by default, Client Components only when needed
- All DB access through Supabase — no direct SQL from client
- Mobile-first responsive — crew uses phones on jobsite
- Every route that touches data requires auth check
- Error states and loading states on every async component
- Keep components small — one responsibility per file
